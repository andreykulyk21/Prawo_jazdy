﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
        [TestMethod]
        public void Test()
      
       


                      {
                int a = 0;
                while (a < 1)
                {
                Console.WriteLine("Eror podaj wynik");

                    a = a + 1;
                }
                if (a > 1)
                {
                Console.WriteLine("Test prawidlowy");
                }
            }
        }
    }


